const { v4: uuidv4 } = require('uuid');
const { Client } = require('@elastic/elasticsearch');

// 1) Initialize Elasticsearch client
const esClient = new Client({
  node: 'https://abae8b591064454f8a57ba1fa55aa13f.asia-southeast1.gcp.elastic-cloud.com:443',
  // If you have an API key:
  auth: { apiKey: 'V21kM1NwVUJaMG5nblZ1bUhZaUk6cUpzLVlCdnJTZGVtN04yNlFWU2ZsUQ==' }
});

const ES_INDEX = 'conversations'; // Adjust as needed

async function startConversation(req, res) {
  try {
    const { userId, conversationId } = req.body;
    if (!userId) {
      return res.status(400).json({ message: 'Missing userId' });
    }

    let newConversationId = conversationId || uuidv4();

    // 1) Check if doc already exists in ES:
    let existingConvo = null;
    const existsResp = await esClient.exists({
      index: ES_INDEX,
      id: newConversationId
    });

    if (existsResp.body === true) {
      // 2) If it does exist, retrieve it
      const getResp = await esClient.get({
        index: ES_INDEX,
        id: newConversationId
      });
      existingConvo = getResp.body._source;
    }

    if (existingConvo) {
      // 3) If we found an existing conversation, just return it
      return res.status(200).json({
        conversationId: newConversationId,
        userId: existingConvo.userId,
        messages: existingConvo.messages
      });
    } else {
      // 4) Otherwise, create a new conversation doc
      const greetingMessage = {
        role: 'assistant',
        text: 'Hello! How can I help you today?',
        timestamp: new Date().toISOString()
      };

      const conversationDoc = {
        conversationId: newConversationId,
        userId: userId,
        createdAt: new Date().toISOString(),
        messages: [greetingMessage]
      };

      await esClient.index({
        index: ES_INDEX,
        id: newConversationId,
        body: conversationDoc,
        refresh: true
      });

      // 5) Return the newly created conversation
      return res.status(201).json({
        conversationId: newConversationId,
        userId,
        messages: conversationDoc.messages
      });
    }
  } catch (err) {
    console.error('Error starting conversation:', err);
    return res.status(500).json({ message: 'Internal Server Error', error: err.message });
  }
}

module.exports = startConversation;